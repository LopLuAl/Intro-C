// #include "mi-header.h"
/*Este es un back de reproductor andando  el dia 25/10/16 4:26 AM*/
#include <dirent.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/soundcard.h>
#include <ctype.h>

/* segundos de audio a grabar */
#define LENGTH 30
/* sampling rate = velocidad de muestreo del audio a la entrada*/
#define RATE 48000
/* sample size = Tamaño de muestra. Típicamente 8 o 16 bits */
#define SIZE 16
/* 1 = mono 2 = stereo */
#define CHANNELS 2

typedef struct nodo
{
    struct nodo * ptr_next;
    struct nodo * ptr_prev;
    void * info;
}NODO;

typedef struct dato
{
    char nombre[256];
    int nro;
}DATO;



void leer_and_load      (NODO **    head);
int  discriminar        (char *     ls);
void crearlista         (NODO ***   head, char *cancion, int numero);
void imprimir_temas     (NODO *     head);
void seleccion_and_play (NODO *     head);
void reproducir         (char * tema      );
void set_audio_params (int fd);

void main (int argc, char * argv [])
{
    NODO * head = NULL;
    printf("Falta hacer un log de los temas seleccionados y que los guarde en una lista con la cantidad de veces que se escucharon\n");
    leer_and_load(&head);
    imprimir_temas(head);
    seleccion_and_play(head);
    return;
}

void leer_and_load(NODO **head)
{
    
    DIR *my_dir;
    struct dirent *my_dir1 = NULL;
    char aux [256];
    int  item, numero=0;
    my_dir=opendir(".");

    while(( my_dir1=readdir(my_dir))!=NULL)
    {
        strcpy(aux,my_dir1->d_name);
        item=discriminar(aux);
        if(item == 1)
        {
            crearlista(&head, aux, numero);
            numero++;
        }
    }
    return;
}
int discriminar(char * ls )
{
    int item = 0, i=0;
    for (i=0;ls[i]!='\0';i++)
    {
            if(ls[i]=='.')
                if(ls[i+1]=='r')
                    if(ls[i+2]=='a')
                        if(ls[i+3]=='w')
                            item=1;
                        
    }
  
    return item;
}

void crearlista     (NODO *** head, char *cancion, int numero)
{
    NODO * elemento;
    DATO * contenido;
    elemento= (NODO*)malloc(sizeof(NODO));
    contenido=(DATO*)malloc(sizeof(DATO));
    /*Le cargo los valores al nodo*/
    strcpy(contenido->nombre,cancion);
    contenido->nro=numero;
    /*Fin de carga de valores al nodo*/
    elemento->info=(void*)contenido;

    ////// ACA VIENE LA MAGIA ;) //////
    if( (**head )== NULL )
    {
        elemento->ptr_next = NULL;
        elemento->ptr_prev = NULL;
        **head = elemento;
        
    }
    else
    {
        (***head).ptr_prev=elemento;
        elemento->ptr_next=**head;
        elemento->ptr_prev=NULL;
        **head=elemento;
    }
    ////// ACA SE TERMINA LA MAGIA ;) //////    
    return;
}
void imprimir_temas (NODO * head)
{
    NODO * aux;
    aux=head;
    printf("Numero\tCancion\n");
    while(aux->ptr_next!=NULL)
    {
        printf("%d\t%s\n",((DATO*)aux->info)->nro,((DATO*)aux->info)->nombre);
        aux=aux->ptr_next;
    }
    printf("%d\t%s\n",((DATO*)aux->info)->nro,((DATO*)aux->info)->nombre);
}
void seleccion_and_play (NODO *     head)
{
    int seleccion;
    NODO * aux;
    aux=head;
    printf("\nSelecione un tema para escuchar\n");
    scanf("%d",&seleccion);
    while(seleccion >=9  || seleccion <=0)
    {
       printf("Ingrese un caracter entre 0 y 10\n");
       scanf("%d",&seleccion);
       getchar();
       
    }
    while(  ((DATO*)aux->info)->nro != seleccion )
        aux=aux->ptr_next;
    printf("Tema seleccionado: %d\t%s\n",((DATO*)aux->info)->nro,((DATO*)aux->info)->nombre);    
    reproducir(((DATO*)aux->info)->nombre);
}
void reproducir         (char * tema      )
{
    int fd, fd_tema,control;
    unsigned char buf[LENGTH*RATE*SIZE*CHANNELS/8];
    
    if (    (fd=open("/dev/dsp",O_RDWR))  < 0 )
        perror ("Error Abrir");
    printf("\n\nAbriendo %s \n",tema);
    if (    (fd_tema=open(tema,O_RDWR) ) < 0 )
        perror ("Error al abrir archivo de musica");
    printf("%s Abierto \n",tema);
    printf("Reproduciendo\n");
    set_audio_params (fd);
    while(1)
    {
        control=read(fd_tema,buf,sizeof(buf));
        /*Verificando si lei todo*/
        if (control!=sizeof(buf))
            perror("Error control:");
        control = write(fd, buf, sizeof(buf)); /* reproduce */
        if (control != sizeof(buf))
        {
            fprintf(stderr,"Error en función write, Código de error: %s\n",strerror (control)); 
        }
    }
}
void set_audio_params (int fd)
{
    int arg;		/* argumento para ioctl */
    int	status;		/* salida de ioctl */

/* seteamos los parametros de muestreo  */
    arg = SIZE;	   /* arg = Tamaño de muestra */
    status = ioctl(fd, SOUND_PCM_WRITE_BITS, &arg); // Escribir en el disp de audio a grabar el tamaño de la muestra. en arg me devuelve de cuanto es lo que realemnte me grabo 
/* SOUND_PCM_WRITE_BITS es la macro que escribe en la placa de sonido (a través del driver por supuesto), el valor del tamaño de muestra en bits que seteamos en la variable arg, cuyo puntero se provee como tercer argumento a ioctl().
La interfaz genérica de audio manejada por streams traduce comandos generales a los comandos particulares para el hardware de modo transparente al programador */
    if (status == -1) 
            perror("Error con comando SOUND_PCM_WRITE_BITS");
/* El hecho que ioctl devuelva error no quiere decir que no se haya configurado el parámetro que se quiso programar.*/
    if (arg != SIZE)
/* Por lo general la variable pasada por referencia vuelve con el valor programado si el original no estaba entre los posibles valores del parámetro que se quiso configurar. Por ejemplo, Tamaño de muestra: si arg hubiese ido en un valor por ejemplo 13, o 15, seguramente no coicidiría con los valores posibles para configurar el conversor A/D de la placa de sonido. 
En tal caso el driver programa al valor mas cercano al argumento recibido,modifica la variable recibda como referencia al valor, para que el programa que lo envió pueda saber el valor con el que se configuró, y hace que la función devuelva -1, para que se pueda analizar el error y tomar nota del valor configurado finalmente. */
            fprintf (stderr,"Tamaño de muestras no soportado. Se programó %d\n",arg);

    arg = CHANNELS;  /* mono o stereo */
    status = ioctl(fd, SOUND_PCM_WRITE_CHANNELS, &arg); // cantidad de canales.
    if (status == -1)
            perror("Error en comando SOUND_PCM_WRITE_CHANNELS");
    if (arg != CHANNELS)
            fprintf (stderr,"Cantidad de canales no soportado. Se programó %d\n",arg);

    arg = RATE;	   /* Velocidad de Muestreo */
    status = ioctl(fd, SOUND_PCM_WRITE_RATE, &arg);
    if (status == -1)
            perror("Error en comando SOUND_PCM_WRITE_RATE");
    if (arg != RATE)
            fprintf (stderr,"Velocidad de muestreo no soportada. Se programó %d\n",arg);

    return;
}
